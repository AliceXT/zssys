<?php

namespace Addons\HcCard\Model;
use Think\Model;

/**
 * HcCard模型
 */
class HcCardModel extends Model{

}
