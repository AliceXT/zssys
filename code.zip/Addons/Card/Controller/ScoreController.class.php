<?php

namespace Addons\Card\Controller;

use Addons\Card\Controller\BaseController;

class ScoreController extends BaseController {
	
	function show(){
		$this->display();
	}
	
}
