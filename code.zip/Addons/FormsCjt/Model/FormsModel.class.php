<?php

namespace Addons\FormsCjt\Model;
use Think\Model;

/**
 * FormsCjt模型
 */
class FormsCjtModel extends Model{

}
