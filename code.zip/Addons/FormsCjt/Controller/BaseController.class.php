<?php

namespace Addons\FormsCjt\Controller;

use Home\Controller\AddonsController;

function get_forms_cjt_id() {
	return $_REQUEST ['forms_cjt_id'];
}
class BaseController extends AddonsController {
}
