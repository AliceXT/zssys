<?php
namespace Addons\Book\Model;
use Think\Model;
/**
 * Book模型
 */
class BookModel extends Model{
	
}
