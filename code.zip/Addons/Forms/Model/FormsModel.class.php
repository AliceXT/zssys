<?php

namespace Addons\Forms\Model;
use Think\Model;

/**
 * Forms模型
 */
class FormsModel extends Model{

}
